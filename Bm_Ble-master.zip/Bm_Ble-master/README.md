# Flutter BLE demo

This is a usage example of flutter_blue by writing an nRF connect like app.
